/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioaula02;

/**
 *
 * @author aluno
 */
public class Contato {
    private String nome;
    private String email;
    
    public Contato ( String n, String e){
    this.nome = n;
    this.email = e;
    }
    
    public String getNome(){
        return this.nome;
    }
    public String getEmail(){
        return this.email;
    }
    public void setNome( String n){
       this.nome = n;
    }
    public void setEmail( String e){
       this.email = e;
    }
    @Override
    public String toString() {
        return "Contato: " + nome + " | Email: " + email;
    }
}
