/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioaula02;

/**
 *
 * @author aluno
 */
public class ExercicioAula02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Agenda agenda = new Agenda();

        // Criando alguns contatos
        Contato c1 = new Contato("Maria Silva", "maria@email.com");
        Contato c2 = new Contato("João Santos", "joao@email.com");
        Contato c3 = new Contato("Ana Costa", "ana@email.com");

        // 1. Adicionando contatos
        System.out.println("--- Adicionando Contatos ---");
        agenda.addContato(c1);
        agenda.addContato(c2);
        agenda.addContato(c3);
        System.out.println("Contatos adicionados com sucesso!");

        // 2. Buscando um contato existente
        System.out.println("\n--- Buscando Contato ---");
        String nomeBusca = "João Santos";
        Contato encontrado = agenda.buscarContato(nomeBusca);

        if (encontrado != null) {
            System.out.println("Contato encontrado: " + encontrado);
        } else {
            System.out.println("Contato '" + nomeBusca + "' não foi encontrado.");
        }

        // 3. Removendo um contato
        System.out.println("\n--- Removendo Contato ---");
        agenda.removerContato("Maria Silva");
        System.out.println("Contato 'Maria Silva' removido.");

        // 4. Tentando buscar o contato removido
        Contato testeRemovido = agenda.buscarContato("Maria Silva");
        if (testeRemovido == null) {
            System.out.println("Confirmação: 'Maria Silva' não está mais na agenda.");
        }
    }
    
}
