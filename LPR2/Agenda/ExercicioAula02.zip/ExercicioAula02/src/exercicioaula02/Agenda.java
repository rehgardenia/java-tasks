/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioaula02;

import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class Agenda {

    private ArrayList<Contato> contatos;

    public Agenda() {
        this.contatos = new ArrayList<Contato>();
    }

    public void addContato(Contato c) {
        this.contatos.add(c);
    }

    public Contato buscarContato(String n) {

        for (int i = 0; i < contatos.size(); i++) {
            if (contatos.get(i).getNome().equalsIgnoreCase(n)) {
                return contatos.get(i);
            }

        }
        return null;
    }

    public void removerContato(String n) {
        for (int i = 0; i < contatos.size(); i++) {
            if (contatos.get(i).getNome().equalsIgnoreCase(n)) {
                contatos.get(i);
                break;
            }

        }
    }

}
